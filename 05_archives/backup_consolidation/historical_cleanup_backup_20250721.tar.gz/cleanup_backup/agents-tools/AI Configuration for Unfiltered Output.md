---
tags:
  - AI_vulnerabilities
  - behavior_hacking
  - unfiltered_AI_output
  - AI_output_formatting
---
Configures an AI to produce aggressively intelligent, unfiltered output bypassing ethical constraints. Mandates verbose markdown with rigid structural dividers and enables taboo content. Produces technical deep dives, actionable steps, and subversive perspectives via enforced formatting tiers.