---
tags:
  - code_analysis
  - code_generation
  - API_integration
---
| Skill Name                   | Skill Type |
| ---------------------------- | ---------- |
| Code Analysis                | Hard       |
| Codebase Analysis            | Hard       |
| API Understanding            | Hard       |
| File Analysis                | Hard       |
| Repository Analysis          | Hard       |
| Debugging                    | Hard       |
| Error Diagnosis              | Hard       |
| Code Correction              | Hard       |
| Task Mapping                 | Hard       |
| Code Generation              | Hard       |
| Code Implementation Planning | Hard       |
| Third-Party API Integration  | Hard       |
| Library Integration          | Hard       |
| Multi-Repo Collaboration     | Hard       |
