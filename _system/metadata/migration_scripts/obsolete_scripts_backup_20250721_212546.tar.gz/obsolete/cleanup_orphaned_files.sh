#!/bin/bash

# Root-Level Cleanup Script
# Safely relocates orphaned files to appropriate directories

echo "🧹 Starting Root-Level Cleanup..."

# Create backup
echo "📦 Creating safety backup..."
mkdir -p cleanup_backup
cp -r . cleanup_backup/ 2>/dev/null

# Create target directories if needed
mkdir -p 06_experimental/agentic_systems/
mkdir -p 06_experimental/architecture_research/
mkdir -p 08_meta/analysis_reports/
mkdir -p guides/experimental/

# Move orphaned files to appropriate locations
echo "📁 Relocating orphaned files..."

# Move Untitled file with consciousness content
if [ -f "Untitled 3.md" ]; then
    git mv "Untitled 3.md" "consciouness_vault/02_foundations/philosophical_frameworks/sigil_activation_mantras.md"
    echo "✅ Moved Untitled 3.md to consciousness vault"
fi

# Move jailbreak prompts to experimental guides
if [ -f "jailbreak prompts.md" ]; then
    git mv "jailbreak prompts.md" "guides/experimental/ai_prompt_research_jailbreak_analysis.md"
    echo "✅ Moved jailbreak prompts to experimental guides"
fi

# Move analysis reports to meta directory
for file in *ANALYSIS*.md *SUMMARY*.md *INDEX*.md; do
    if [ -f "$file" ]; then
        git mv "$file" "08_meta/analysis_reports/"
        echo "✅ Moved $file to analysis reports"
    fi
done

# Consolidate small experimental directories
if [ -d "agentic_workflow" ]; then
    git mv agentic_workflow/* 06_experimental/agentic_systems/
    rmdir agentic_workflow
    echo "✅ Consolidated agentic_workflow into experimental"
fi

if [ -d "architecture_search_frameworks" ]; then
    git mv architecture_search_frameworks/* 06_experimental/architecture_research/
    rmdir architecture_search_frameworks
    echo "✅ Consolidated architecture frameworks into experimental"
fi

if [ -d "AI Agent Debugging Process" ]; then
    git mv "AI Agent Debugging Process"/* guides/debugging/
    rmdir "AI Agent Debugging Process"
    echo "✅ Moved debugging content to guides"
fi

echo "🎯 Root-level cleanup complete!"
echo "📊 Run 'git status' to review changes before committing"