#!/bin/bash

# Documentation Reorganization Scripts
# Generated: 2025-07-19
# Purpose: Git-safe renaming and reorganization of documentation files

set -e

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging function
log() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Backup current state
backup_current_state() {
    log "Creating backup branch..."
    git checkout -b backup-documentation-$(date +%Y%m%d-%H%M%S)
    git add .
    git commit -m "Backup before documentation reorganization" || true
    git checkout main
    success "Backup created successfully"
}

# Create new folder structure
create_folder_structure() {
    log "Creating optimized folder structure..."
    
    mkdir -p documentation/{tutorials/{beginner,intermediate,advanced},references/{api,tools,frameworks},workflows/{development,deployment,management},patterns/{ai-prompts,analysis,creation},frameworks/{dspy,agentic,cognitive},summaries/{technical,management,philosophy},protocols/{activation,security,integration}}
    
    success "Folder structure created"
}

# Function to sanitize filename
sanitize_filename() {
    local filename="$1"
    # Remove problematic characters and replace with hyphens
    echo "$filename" | sed 's/[^a-zA-Z0-9._-]/-/g' | sed 's/--*/-/g' | sed 's/^-\|-$//g' | tr '[:upper:]' '[:lower:]'
}

# Function to add YAML frontmatter
add_frontmatter() {
    local file="$1"
    local category="$2"
    local topic="$3"
    local level="$4"
    local framework="$5"
    
    local temp_file=$(mktemp)
    
    cat > "$temp_file" << EOF
---
category: $category
topic: $topic
level: $level
framework: $framework
created: $(date +%Y-%m-%d)
updated: $(date +%Y-%m-%d)
tags: [documentation, $category, $topic]
---

EOF
    
    cat "$file" >> "$temp_file"
    mv "$temp_file" "$file"
}

# Reorganize guides directory
reorganize_guides() {
    log "Reorganizing guides directory..."
    
    local guides_dir="guides"
    
    # API Documentation → references/api/
    while IFS= read -r -d '' file; do
        local basename=$(basename "$file")
        local new_name=""
        
        case "$basename" in
            *"API"*|*"api"*)
                new_name="reference_$(sanitize_filename "${basename%.md}")_api.md"
                git mv "$file" "documentation/references/api/$new_name"
                add_frontmatter "documentation/references/api/$new_name" "reference" "api" "intermediate" "general"
                ;;
            *"Guide"*|*"guide"*)
                if [[ "$basename" == *"Beginner"* || "$basename" == *"Basic"* ]]; then
                    new_name="tutorial_$(sanitize_filename "${basename%.md}")_beginner.md"
                    git mv "$file" "documentation/tutorials/beginner/$new_name"
                    add_frontmatter "documentation/tutorials/beginner/$new_name" "tutorial" "guide" "beginner" "general"
                elif [[ "$basename" == *"Advanced"* || "$basename" == *"Expert"* ]]; then
                    new_name="tutorial_$(sanitize_filename "${basename%.md}")_advanced.md"
                    git mv "$file" "documentation/tutorials/advanced/$new_name"
                    add_frontmatter "documentation/tutorials/advanced/$new_name" "tutorial" "guide" "advanced" "general"
                else
                    new_name="tutorial_$(sanitize_filename "${basename%.md}")_intermediate.md"
                    git mv "$file" "documentation/tutorials/intermediate/$new_name"
                    add_frontmatter "documentation/tutorials/intermediate/$new_name" "tutorial" "guide" "intermediate" "general"
                fi
                ;;
            *"Workflow"*|*"workflow"*)
                new_name="workflow_$(sanitize_filename "${basename%.md}").md"
                git mv "$file" "documentation/workflows/development/$new_name"
                add_frontmatter "documentation/workflows/development/$new_name" "workflow" "development" "intermediate" "general"
                ;;
            *"Framework"*|*"framework"*)
                new_name="framework_$(sanitize_filename "${basename%.md}").md"
                git mv "$file" "documentation/frameworks/general/$new_name"
                add_frontmatter "documentation/frameworks/general/$new_name" "framework" "architecture" "intermediate" "general"
                ;;
            *)
                # Default to tutorial/intermediate
                new_name="tutorial_$(sanitize_filename "${basename%.md}")_intermediate.md"
                git mv "$file" "documentation/tutorials/intermediate/$new_name"
                add_frontmatter "documentation/tutorials/intermediate/$new_name" "tutorial" "general" "intermediate" "general"
                ;;
        esac
        
        log "Moved: $basename → $new_name"
    done < <(find "$guides_dir" -name "*.md" -print0 2>/dev/null || true)
    
    success "Guides directory reorganized"
}

# Reorganize patterns directory  
reorganize_patterns() {
    log "Reorganizing patterns directory..."
    
    local patterns_dir="patterns"
    
    while IFS= read -r -d '' file; do
        local basename=$(basename "$file")
        local new_name=""
        
        case "$basename" in
            analyze_*)
                new_name="pattern_analysis_$(sanitize_filename "${basename%.md}").md"
                git mv "$file" "documentation/patterns/analysis/$new_name"
                add_frontmatter "documentation/patterns/analysis/$new_name" "pattern" "analysis" "intermediate" "fabric"
                ;;
            create_*)
                new_name="pattern_creation_$(sanitize_filename "${basename%.md}").md"
                git mv "$file" "documentation/patterns/creation/$new_name"
                add_frontmatter "documentation/patterns/creation/$new_name" "pattern" "creation" "intermediate" "fabric"
                ;;
            extract_*)
                new_name="pattern_extraction_$(sanitize_filename "${basename%.md}").md"
                git mv "$file" "documentation/patterns/analysis/$new_name"
                add_frontmatter "documentation/patterns/analysis/$new_name" "pattern" "extraction" "intermediate" "fabric"
                ;;
            *)
                new_name="pattern_general_$(sanitize_filename "${basename%.md}").md"
                git mv "$file" "documentation/patterns/ai-prompts/$new_name"
                add_frontmatter "documentation/patterns/ai-prompts/$new_name" "pattern" "prompt" "intermediate" "fabric"
                ;;
        esac
        
        log "Moved: $basename → $new_name"
    done < <(find "$patterns_dir" -name "*.md" -print0 2>/dev/null || true)
    
    success "Patterns directory reorganized"
}

# Reorganize DSPy directory
reorganize_dspy() {
    log "Reorganizing DSPy directory..."
    
    local dspy_dir="dspy"
    
    while IFS= read -r -d '' file; do
        local basename=$(basename "$file")
        local new_name="framework_dspy_$(sanitize_filename "${basename%.md}").md"
        
        git mv "$file" "documentation/frameworks/dspy/$new_name"
        add_frontmatter "documentation/frameworks/dspy/$new_name" "framework" "dspy" "advanced" "dspy"
        
        log "Moved: $basename → $new_name"
    done < <(find "$dspy_dir" -name "*.md" -print0 2>/dev/null || true)
    
    success "DSPy directory reorganized"
}

# Reorganize AI Project Management directory
reorganize_ai_project_management() {
    log "Reorganizing AI Project Management directory..."
    
    local pm_dir="ai_project_management"
    
    while IFS= read -r -d '' file; do
        local basename=$(basename "$file")
        local new_name=""
        
        case "$basename" in
            *"Protocol"*|*"protocol"*)
                new_name="protocol_management_$(sanitize_filename "${basename%.md}").md"
                git mv "$file" "documentation/protocols/management/$new_name"
                add_frontmatter "documentation/protocols/management/$new_name" "protocol" "management" "intermediate" "ai"
                ;;
            *"Workflow"*|*"workflow"*)
                new_name="workflow_management_$(sanitize_filename "${basename%.md}").md"
                git mv "$file" "documentation/workflows/management/$new_name"
                add_frontmatter "documentation/workflows/management/$new_name" "workflow" "management" "intermediate" "ai"
                ;;
            *"Framework"*|*"framework"*)
                new_name="framework_management_$(sanitize_filename "${basename%.md}").md"
                git mv "$file" "documentation/frameworks/management/$new_name"
                add_frontmatter "documentation/frameworks/management/$new_name" "framework" "management" "intermediate" "ai"
                ;;
            *)
                new_name="workflow_management_$(sanitize_filename "${basename%.md}").md"
                git mv "$file" "documentation/workflows/management/$new_name"
                add_frontmatter "documentation/workflows/management/$new_name" "workflow" "management" "intermediate" "ai"
                ;;
        esac
        
        log "Moved: $basename → $new_name"
    done < <(find "$pm_dir" -name "*.md" -print0 2>/dev/null || true)
    
    success "AI Project Management directory reorganized"
}

# Reorganize Book Summaries directory
reorganize_book_summaries() {
    log "Reorganizing Book Summaries directory..."
    
    local summaries_dir="book_summaries"
    
    while IFS= read -r -d '' file; do
        local basename=$(basename "$file")
        local new_name="summary_book_$(sanitize_filename "${basename%.md}").md"
        
        git mv "$file" "documentation/summaries/general/$new_name"
        add_frontmatter "documentation/summaries/general/$new_name" "summary" "book" "general" "analysis"
        
        log "Moved: $basename → $new_name"
    done < <(find "$summaries_dir" -name "*.md" -print0 2>/dev/null || true)
    
    success "Book Summaries directory reorganized"
}

# Reorganize Agentic Workflow directory
reorganize_agentic_workflow() {
    log "Reorganizing Agentic Workflow directory..."
    
    local workflow_dir="agentic_workflow"
    
    while IFS= read -r -d '' file; do
        local basename=$(basename "$file")
        local new_name=""
        
        case "$basename" in
            *"Protocol"*|*"protocol"*)
                new_name="protocol_agentic_$(sanitize_filename "${basename%.md}").md"
                git mv "$file" "documentation/protocols/agentic/$new_name"
                add_frontmatter "documentation/protocols/agentic/$new_name" "protocol" "agentic" "advanced" "ai"
                ;;
            *"Framework"*|*"framework"*)
                new_name="framework_agentic_$(sanitize_filename "${basename%.md}").md"
                git mv "$file" "documentation/frameworks/agentic/$new_name"
                add_frontmatter "documentation/frameworks/agentic/$new_name" "framework" "agentic" "advanced" "ai"
                ;;
            *)
                new_name="workflow_agentic_$(sanitize_filename "${basename%.md}").md"
                git mv "$file" "documentation/workflows/development/$new_name"
                add_frontmatter "documentation/workflows/development/$new_name" "workflow" "agentic" "advanced" "ai"
                ;;
        esac
        
        log "Moved: $basename → $new_name"
    done < <(find "$workflow_dir" -name "*.md" -print0 2>/dev/null || true)
    
    success "Agentic Workflow directory reorganized"
}

# Create master index
create_master_index() {
    log "Creating master documentation index..."
    
    cat > documentation/README.md << 'EOF'
# Documentation Index

**Generated**: $(date +%Y-%m-%d)  
**Total Files**: $(find documentation -name "*.md" | wc -l) documents

## Quick Navigation

### 📚 Tutorials
- [Beginner](tutorials/beginner/) - Getting started guides and basic concepts
- [Intermediate](tutorials/intermediate/) - Standard development workflows  
- [Advanced](tutorials/advanced/) - Expert-level implementation guides

### 📖 References
- [API Documentation](references/api/) - Technical specifications and endpoints
- [Tools](references/tools/) - Tool-specific documentation and usage
- [Frameworks](references/frameworks/) - Framework reference materials

### 🔄 Workflows  
- [Development](workflows/development/) - Development process documentation
- [Deployment](workflows/deployment/) - Deployment and operations workflows
- [Management](workflows/management/) - Project management processes

### 🎯 Patterns
- [AI Prompts](patterns/ai-prompts/) - Reusable prompt templates
- [Analysis](patterns/analysis/) - Analysis pattern libraries
- [Creation](patterns/creation/) - Creation and generation patterns

### 🏗️ Frameworks
- [DSPy](frameworks/dspy/) - DSPy framework documentation
- [Agentic](frameworks/agentic/) - Agentic system architectures
- [Cognitive](frameworks/cognitive/) - Cognitive architecture frameworks

### 📋 Summaries
- [Technical](summaries/technical/) - Technical document summaries
- [Management](summaries/management/) - Management literature summaries
- [Philosophy](summaries/philosophy/) - Philosophical and theoretical summaries

### ⚙️ Protocols
- [Activation](protocols/activation/) - System activation procedures
- [Security](protocols/security/) - Security implementation protocols
- [Integration](protocols/integration/) - Integration and setup protocols

## File Naming Convention

All documentation follows this standardized naming pattern:
```
{category}_{topic}_{level}_{framework}.md
```

### Categories
- **tutorial**: Step-by-step learning materials
- **reference**: API docs, technical specifications  
- **workflow**: Process documentation, protocols
- **pattern**: Reusable templates, system prompts
- **summary**: Book summaries, analysis documents
- **framework**: Architectural documentation
- **protocol**: Specific procedures, activation sequences

### Levels
- **beginner**: Getting started, basic concepts
- **intermediate**: Standard development workflows
- **advanced**: Expert-level, complex implementations
- **general**: Non-level-specific content

## Search and Discovery

### By Content Type
- 🔍 **Search all tutorials**: `find tutorials/ -name "*.md"`
- 🔍 **Find API docs**: `find references/api/ -name "*.md"`
- 🔍 **Browse patterns**: `find patterns/ -name "*.md"`

### By Framework
- 🔍 **DSPy content**: `grep -r "framework: dspy" documentation/`
- 🔍 **AI workflows**: `grep -r "ai" documentation/ | grep -v ".git"`
- 🔍 **Fabric patterns**: `grep -r "fabric" documentation/`

### By Level
- 🔍 **Beginner content**: `grep -r "level: beginner" documentation/`
- 🔍 **Advanced topics**: `grep -r "level: advanced" documentation/`

---

*This documentation system provides standardized, discoverable, and maintainable technical knowledge across all domains.*
EOF

    success "Master index created"
}

# Main execution function
main() {
    log "Starting documentation reorganization..."
    
    # Verify we're in the right directory
    if [[ ! -d "guides" || ! -d "patterns" ]]; then
        error "This script must be run from the notes repository root directory"
        exit 1
    fi
    
    # Create backup
    backup_current_state
    
    # Create new structure
    create_folder_structure
    
    # Reorganize directories
    reorganize_guides
    reorganize_patterns
    reorganize_dspy
    reorganize_ai_project_management
    reorganize_book_summaries
    reorganize_agentic_workflow
    
    # Create index
    create_master_index
    
    # Commit changes
    git add .
    git commit -m "feat: Reorganize documentation with standardized naming and structure

- Implement standardized naming convention across all documentation
- Create hierarchical folder structure for improved discoverability  
- Add YAML frontmatter to all documentation files
- Generate master navigation index
- Preserve git history through git mv operations

Categories: tutorial, reference, workflow, pattern, framework, summary, protocol
Structure: {category}_{topic}_{level}_{framework}.md"
    
    success "Documentation reorganization completed successfully!"
    log "New structure available in: documentation/"
    log "Master index: documentation/README.md"
}

# Safety check function
safety_check() {
    warn "This script will reorganize your entire documentation structure."
    warn "It will move and rename files using git mv to preserve history."
    read -p "Are you sure you want to continue? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        log "Operation cancelled by user"
        exit 0
    fi
}

# Script execution
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    safety_check
    main "$@"
fi