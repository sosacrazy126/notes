#!/bin/bash

# Documentation Structure Validation Script
# Generated: 2025-07-19
# Purpose: Validate documentation organization and identify issues

set -e

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

# Counters
total_files=0
total_issues=0
duplicate_files=0
broken_links=0
missing_headers=0

# Logging functions
log() { echo -e "${BLUE}[INFO]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; ((total_issues++)); }
error() { echo -e "${RED}[ERROR]${NC} $1"; ((total_issues++)); }
success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
header() { echo -e "${PURPLE}=== $1 ===${NC}"; }

# Generate comprehensive report
generate_report() {
    local output_file="documentation_validation_report.md"
    
    cat > "$output_file" << EOF
# Documentation Validation Report

**Generated**: $(date +'%Y-%m-%d %H:%M:%S')  
**Total Files Analyzed**: $total_files  
**Issues Found**: $total_issues  

## Summary Statistics

| Metric | Count | Status |
|--------|-------|--------|
| Total Markdown Files | $total_files | ✅ |
| Duplicate Files | $duplicate_files | $([ $duplicate_files -gt 0 ] && echo "⚠️" || echo "✅") |
| Broken Internal Links | $broken_links | $([ $broken_links -gt 0 ] && echo "❌" || echo "✅") |
| Missing Headers | $missing_headers | $([ $missing_headers -gt 0 ] && echo "⚠️" || echo "✅") |
| Total Issues | $total_issues | $([ $total_issues -gt 0 ] && echo "❌" || echo "✅") |

## Directory Analysis

### File Distribution
\`\`\`
$(find . -name "*.md" -type f | grep -v ".git" | sort | awk -F'/' '{print $2}' | uniq -c | sort -nr)
\`\`\`

### Largest Files
\`\`\`
$(find . -name "*.md" -type f -exec ls -lh {} \; | sort -k5 -hr | head -10 | awk '{print $5, $9}')
\`\`\`

### Recent Files
\`\`\`
$(find . -name "*.md" -type f -mtime -7 | head -10)
\`\`\`

## Naming Convention Analysis

### Problematic Filenames
$(find . -name "*.md" -type f | grep -E '\(|\)|\*|:|;|<|>|\?|\[|\]|\|' | head -20)

### Date-Prefixed Files
$(find . -name "2025-*.md" -type f | wc -l) files with date prefixes

### Duplicate Indicators
$(find . -name "*(*).md" -type f | wc -l) files with duplicate indicators

## Content Quality Issues

### Files Without Headers
$(find . -name "*.md" -type f -exec grep -L "^#" {} \; | wc -l) files missing main headers

### Very Short Files (<100 bytes)
$(find . -name "*.md" -type f -size -100c | wc -l) files under 100 bytes

### Very Large Files (>100KB)
$(find . -name "*.md" -type f -size +100k | wc -l) files over 100KB

## Recommendations

### High Priority
1. **Standardize Naming**: Implement consistent naming convention
2. **Remove Duplicates**: Consolidate duplicate content files
3. **Fix Broken Links**: Update internal references and links
4. **Add Headers**: Ensure all files have proper H1 headers

### Medium Priority  
1. **Organize Structure**: Implement hierarchical folder organization
2. **Add Metadata**: Include YAML frontmatter for categorization
3. **Create Indexes**: Generate navigation aids for discovery
4. **Update Content**: Review and refresh outdated information

### Low Priority
1. **Archive Old Content**: Move dated experimental content
2. **Standardize Formats**: Consistent markdown formatting
3. **Cross-Reference**: Link related documentation
4. **Generate TOCs**: Add table of contents to long documents

---

*Run this validation script regularly to maintain documentation quality and organization.*
EOF

    success "Validation report generated: $output_file"
}

# Check for duplicate files based on content similarity
check_duplicates() {
    header "Checking for Duplicate Files"
    
    local temp_dir=$(mktemp -d)
    local duplicates_found=false
    
    # Find files with similar names
    find . -name "*.md" -type f | while read file; do
        local basename=$(basename "$file" .md)
        local similar_files=$(find . -name "*${basename}*" -type f | grep -v "^${file}$")
        
        if [[ -n "$similar_files" ]]; then
            warn "Potential duplicates for: $file"
            echo "$similar_files" | sed 's/^/  - /'
            ((duplicate_files++))
            duplicates_found=true
        fi
    done
    
    # Check for exact filename duplicates (case insensitive)
    find . -name "*.md" -type f | while read file; do
        local basename=$(basename "$file")
        local lowercase_name=$(echo "$basename" | tr '[:upper:]' '[:lower:]')
        local same_name_files=$(find . -name "*.md" -type f -exec basename {} \; | tr '[:upper:]' '[:lower:]' | grep -c "^${lowercase_name}$")
        
        if [[ $same_name_files -gt 1 ]]; then
            warn "Multiple files with similar names: $basename"
            ((duplicate_files++))
        fi
    done
    
    rm -rf "$temp_dir"
    
    if [[ $duplicates_found == false ]]; then
        success "No obvious duplicates found"
    fi
}

# Validate internal links
check_internal_links() {
    header "Checking Internal Links"
    
    local links_checked=0
    local broken_found=false
    
    find . -name "*.md" -type f | while read file; do
        # Extract markdown links [text](path)
        grep -o '\[.*\](.*\.md)' "$file" 2>/dev/null | while read link; do
            local link_path=$(echo "$link" | sed 's/.*](\(.*\))/\1/')
            local absolute_path=""
            
            # Handle relative paths
            if [[ "$link_path" =~ ^/ ]]; then
                absolute_path=".$link_path"
            else
                absolute_path="$(dirname "$file")/$link_path"
            fi
            
            if [[ ! -f "$absolute_path" ]]; then
                error "Broken link in $file: $link"
                ((broken_links++))
                broken_found=true
            fi
            ((links_checked++))
        done
    done
    
    log "Checked $links_checked internal links"
    
    if [[ $broken_found == false ]]; then
        success "No broken internal links found"
    fi
}

# Check file structure and headers
check_file_structure() {
    header "Checking File Structure"
    
    local files_without_headers=0
    local very_short_files=0
    local very_large_files=0
    
    find . -name "*.md" -type f | while read file; do
        ((total_files++))
        
        # Check for main header
        if ! grep -q "^# " "$file" 2>/dev/null; then
            warn "No H1 header in: $file"
            ((missing_headers++))
            ((files_without_headers++))
        fi
        
        # Check file size
        local file_size=$(stat -f%z "$file" 2>/dev/null || stat -c%s "$file" 2>/dev/null)
        
        if [[ $file_size -lt 100 ]]; then
            warn "Very short file (${file_size}B): $file"
            ((very_short_files++))
        elif [[ $file_size -gt 102400 ]]; then
            warn "Very large file (${file_size}B): $file"  
            ((very_large_files++))
        fi
    done
    
    log "Found $files_without_headers files without headers"
    log "Found $very_short_files very short files"
    log "Found $very_large_files very large files"
}

# Analyze naming conventions
analyze_naming() {
    header "Analyzing Naming Conventions"
    
    local problematic_names=0
    local date_prefixed=0
    local duplicate_indicators=0
    
    find . -name "*.md" -type f | while read file; do
        local basename=$(basename "$file")
        
        # Check for problematic characters
        if [[ "$basename" =~ [\(\)\*:;<>\?\[\]\|] ]]; then
            warn "Problematic filename characters: $basename"
            ((problematic_names++))
        fi
        
        # Check for date prefixes
        if [[ "$basename" =~ ^2025- ]]; then
            ((date_prefixed++))
        fi
        
        # Check for duplicate indicators
        if [[ "$basename" =~ \([0-9]+\) ]]; then
            warn "Duplicate indicator in filename: $basename"
            ((duplicate_indicators++))
        fi
    done
    
    log "Found $problematic_names files with problematic characters"
    log "Found $date_prefixed files with date prefixes"  
    log "Found $duplicate_indicators files with duplicate indicators"
}

# Check directory organization
analyze_directory_structure() {
    header "Analyzing Directory Structure"
    
    # Count files per directory
    find . -maxdepth 2 -type d | while read dir; do
        local file_count=$(find "$dir" -maxdepth 1 -name "*.md" | wc -l)
        if [[ $file_count -gt 50 ]]; then
            warn "Directory with many files ($file_count): $dir"
        elif [[ $file_count -gt 0 ]]; then
            log "Directory $dir: $file_count files"
        fi
    done
    
    # Check for deeply nested structure
    local max_depth=$(find . -type f -name "*.md" | awk -F'/' '{print NF}' | sort -nr | head -1)
    if [[ $max_depth -gt 5 ]]; then
        warn "Deep nesting detected (max depth: $max_depth levels)"
    fi
    
    success "Directory structure analysis complete"
}

# Main validation function
main() {
    header "Documentation Structure Validation"
    log "Starting validation of documentation structure..."
    
    # Verify we're in the right directory
    if [[ ! -d "guides" && ! -d "patterns" ]]; then
        error "This script must be run from the notes repository root directory"
        exit 1
    fi
    
    # Run all validation checks
    analyze_directory_structure
    analyze_naming
    check_file_structure  
    check_duplicates
    check_internal_links
    
    # Generate comprehensive report
    generate_report
    
    # Final summary
    header "Validation Summary"
    if [[ $total_issues -eq 0 ]]; then
        success "✅ All validation checks passed! Documentation structure is excellent."
    elif [[ $total_issues -lt 10 ]]; then
        warn "⚠️ Found $total_issues minor issues. Documentation structure is good but could be improved."
    else
        error "❌ Found $total_issues issues. Documentation structure needs significant improvement."
    fi
    
    log "📊 Total files analyzed: $total_files"
    log "📋 Detailed report: documentation_validation_report.md"
}

# Help function
show_help() {
    echo "Documentation Structure Validation Script"
    echo ""
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  -h, --help     Show this help message"
    echo "  -q, --quiet    Suppress verbose output"
    echo "  -r, --report   Generate report only"
    echo ""
    echo "This script validates documentation organization and identifies:"
    echo "  • Duplicate files and naming conflicts"
    echo "  • Broken internal links and references"
    echo "  • Missing headers and malformed files"
    echo "  • Problematic naming conventions"
    echo "  • Directory organization issues"
    echo ""
    echo "Run from the notes repository root directory."
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -h|--help)
            show_help
            exit 0
            ;;
        -q|--quiet)
            exec 1>/dev/null
            shift
            ;;
        -r|--report)
            generate_report
            exit 0
            ;;
        *)
            error "Unknown option: $1"
            show_help
            exit 1
            ;;
    esac
done

# Execute main function
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi